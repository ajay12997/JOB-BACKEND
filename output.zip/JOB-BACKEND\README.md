This is the backend service for a Job Portal Application, built with Node.js, Express, and MongoDB. It provides APIs for user authentication, job postings, applications, and resume management.
